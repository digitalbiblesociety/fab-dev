function o(t,u){var n;if(t.type)return t.type;let e=(n=t.as)!=null?n:"button";if(typeof e=="string"&&e.toLowerCase()==="button"||u instanceof HTMLButtonElement)return"button"}export{o as r};
